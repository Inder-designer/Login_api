# Ico client panel apis
Node version 14:0.0

```
git clone or setup project
cd dir
npm i 
npm run dev
default users are in bootstrap in util folder
/swagger - to access swagger documentation


For setup on server, install pm2 and run npm start
```
