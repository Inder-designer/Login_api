export const STATUS_PENDING = 1
export const STATUS_APPROVED = 2
export const STATUS_REJECTED = 3
export const KYC_STATUS = {
    PENDING:'PENDING',
    INPROGRESS:'INPROGRESS',
    COMPLETED:'COMPLETED'
}
export const USER_ROLE = 2
export const ADMIN_ROLE = 1
export const SubAdmin_ROLE = 3
export const CRYPTO = {
    ALGO: "aes-256-cbc",
    PWD: "d6F%feq$33!23123"
}
