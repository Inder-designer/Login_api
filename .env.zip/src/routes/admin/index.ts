module.exports = {
    user: require('./admin')
}