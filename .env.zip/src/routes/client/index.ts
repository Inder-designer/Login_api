module.exports = {
    client: require('./client')
}